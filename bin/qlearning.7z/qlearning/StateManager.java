package qlearning;

import java.awt.Dimension;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Random;
import java.util.Scanner;

import javax.imageio.ImageIO;
import javax.swing.Action;

import core.game.StateObservation;
import core.game.Observation;
import ontology.Types.ACTIONS;
import tools.Vector2d;

public class StateManager {
	public static boolean verbose = false;
	// Variables simulacion training
	public static int numIteraciones;
	public static int iteracionActual;
	Random randomGenerator;
	public static boolean metaDerecha = false;
	// Variables comunes a varias clases
	public static int numCol;
	public static int numFilas;

	// Diccionario ESTADOS-BOOLEAN, que indicar� si un estado ha sido capturado en
	// imagen
	public static HashMap<ESTADOS, Boolean> diccionarioEstadoCaptura = new HashMap<ESTADOS, Boolean>();

	/* Contenedor de constantes para identificar los estados */
	public static enum ESTADOS {
		HUECO_ARRIBA(0), HUECO_ABAJO(0), HUECO_IZQDA(0), HUECO_DCHA(0), OBSTACULOS_ARRIBA(0), OBSTACULOS_IZQDA(0),
		OBSTACULOS_DCHA(0), OBSTACULOS_ABAJO(0), BORDE_ARRIBA(0), BORDE_ABAJO(0), BORDE_IZQDA(0), LLEGA_META(0), NIL(0);

		private int contador; // Cuenta cada vez que se percibe ese estado

		ESTADOS(int c) {
			this.contador = c;
		}

		ESTADOS() {
			this.contador = 0;
		}

		public void incrementa() {
			this.contador++;
		}

		public int getContador() {
			return this.contador;
		}

		// Devuelve el enum ESTADOS al que se corresponde la cadena pasada por parametro
		public static ESTADOS buscaEstado(String nombreEstado) {
			for (ESTADOS s : ESTADOS.values()) {
				if (s.toString().equals(nombreEstado))
					return s;
			}

			return null;
		}
	}

	// Acciones posibles
	public static final ACTIONS[] ACCIONES = { ACTIONS.ACTION_UP, ACTIONS.ACTION_DOWN, ACTIONS.ACTION_LEFT,
			ACTIONS.ACTION_RIGHT, ACTIONS.ACTION_NIL};


	public static HashMap<ParEstadoAccion, Integer> R; // TABLA R
	public static HashMap<ParEstadoAccion, Double> Q; // TABLA Q

	/* Variables */
	// private static char mapaObstaculos[][];
	private static int posActual[];
	private int numEstados = ESTADOS.values().length;
	private int numAcciones = ACCIONES.length;

	public StateManager(boolean randomTablaQ, boolean verbose) {
		if (verbose)
			System.out.println("Inicializando tablas Q y R.....");

		randomGenerator = new Random();
		inicializaTablaR();

		inicializaTablaQ(randomTablaQ);

		StateManager.verbose = verbose;

		for (ESTADOS estado : StateManager.ESTADOS.values()) {
			diccionarioEstadoCaptura.put(estado, false);
		}
	}

	public StateManager(String ficheroTablaQ, boolean verbose) {
		if (verbose)
			System.out.println("Inicializando tablas Q y R.....");

		randomGenerator = new Random();
		inicializaTablaR();
		inicializaTablaQ(true);
		cargaTablaQ(ficheroTablaQ);

		StateManager.verbose = verbose;
	}

	public static void capturaEstado(String fileName) throws Exception {
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		Rectangle screenRectangle = new Rectangle(8, 2, 240, 390);

		Robot robot = new Robot();
		BufferedImage image = robot.createScreenCapture(screenRectangle);
		ImageIO.write(image, "bmp", new File("./capturas/" + fileName + ".bmp"));
	}

// ---------------------------------------------------------------------
//  					METODOS TABLAS APRENDIZAJE
// ---------------------------------------------------------------------
	private void inicializaTablaR() {
		R = new HashMap<ParEstadoAccion, Integer>(numEstados * numAcciones);

		int valorRecompensa = 0;

		for (ESTADOS e : ESTADOS.values()) {
			for (ACTIONS a : ACCIONES) {
				R.put(new ParEstadoAccion(e, a), valorRecompensa);
			}
		}
		
		

		//R.put(new ParEstadoAccion(ESTADOS.BORDE_DCHA, ACTIONS.ACTION_RIGHT), -100);
		R.put(new ParEstadoAccion(ESTADOS.BORDE_IZQDA, ACTIONS.ACTION_LEFT), -100);
		R.put(new ParEstadoAccion(ESTADOS.BORDE_ARRIBA, ACTIONS.ACTION_UP), -100);
		R.put(new ParEstadoAccion(ESTADOS.BORDE_ABAJO, ACTIONS.ACTION_DOWN), -100);
		// para que no choque con los obstaculos
		R.put(new ParEstadoAccion(ESTADOS.OBSTACULOS_ARRIBA, ACTIONS.ACTION_UP), -100);
		R.put(new ParEstadoAccion(ESTADOS.OBSTACULOS_ABAJO, ACTIONS.ACTION_DOWN), -100);
		R.put(new ParEstadoAccion(ESTADOS.OBSTACULOS_IZQDA, ACTIONS.ACTION_LEFT), -100);
		R.put(new ParEstadoAccion(ESTADOS.OBSTACULOS_DCHA, ACTIONS.ACTION_RIGHT), -100);
		
		R.put(new ParEstadoAccion(ESTADOS.HUECO_IZQDA, ACTIONS.ACTION_LEFT), 100); // no queremos q vaya a la der
		R.put(new ParEstadoAccion(ESTADOS.HUECO_DCHA, ACTIONS.ACTION_RIGHT), 100);
		R.put(new ParEstadoAccion(ESTADOS.HUECO_ABAJO, ACTIONS.ACTION_DOWN), 50); 
		R.put(new ParEstadoAccion(ESTADOS.HUECO_ARRIBA, ACTIONS.ACTION_UP), 50);
		
		R.put(new ParEstadoAccion(ESTADOS.LLEGA_META, ACTIONS.ACTION_NIL), 1500);
		
		
		

	}

	/*
	 * Inializamos la TablaQ
	 */
	private void inicializaTablaQ(boolean random) {
		Q = new HashMap<ParEstadoAccion, Double>(numEstados * numAcciones);

		if (random) {
			/* Inicializamos todos los valores Q a random */
			for (ESTADOS estado : ESTADOS.values())
				for (ACTIONS accion : ACCIONES)
					Q.put(new ParEstadoAccion(estado, accion), (randomGenerator.nextDouble() + 1) * 50);
		} else {
			/* Inicializamos todos los valores Q a cero */
			for (ESTADOS estado : ESTADOS.values())
				for (ACTIONS accion : ACCIONES) {
					Q.put(new ParEstadoAccion(estado, accion), 0.0);
					// System.out.println(estado.toString() + "," + accion.toString() + " = 0.0");
				}
		}

	}

	/**
	 * Si no le indicamos el nombre del fichero, usa uno por defecto.
	 */
	public void saveQTable() {
		saveQTable("TablaQ.csv");
	}

	/**
	 * Escribe la tabla Q del atributo de la clase en el fichero QTable.csv, para
	 * poder ser le�da en una siguiente etapa de aprendizaje.
	 */
	public void saveQTable(String fileName) {
		/* Creaci�n del fichero de salida */
		try (PrintWriter csvFile = new PrintWriter(new File(fileName))) {

			if (verbose)
				System.out.println(" GENERANDO EL FICHERO DE LA TABLAQ... ");

			StringBuilder buffer = new StringBuilder();
			buffer.append("ESTADOS");
			buffer.append(";");

			for (ACTIONS accion : StateManager.ACCIONES) {
				buffer.append(accion.toString());
				buffer.append(";");
			}

			buffer.append("\n");

			for (ESTADOS estado : ESTADOS.values()) {
				buffer.append(estado.toString());
				buffer.append(";");

				for (ACTIONS accion : StateManager.ACCIONES) {
					double value = StateManager.Q.get(new ParEstadoAccion(estado, accion));

					buffer.append('"' + Double.toString(value).replace('.', ',') + '"');
					buffer.append(";");
				}

				buffer.append("\n");
			}

			csvFile.write(buffer.toString());

			if (verbose)
				System.out.println(" FICHERO GENERADO CORRECTAMENTE! ");

			csvFile.close();

		} catch (Exception ex) {
			System.out.println(ex.getMessage());
		}
	}

	private void cargaTablaQ(String filename) {

		/* Creaci�n del fichero de salida */
		try (Scanner fichero = new Scanner(new File(filename));) {

			if (verbose)
				System.out.println(" CARGANDO EL FICHERO DE LA TABLAQ: " + filename);

			String linea = fichero.nextLine();
			String[] cabecera = linea.split(";");

			ACTIONS[] actions = new ACTIONS[cabecera.length];

			for (int i = 1; i < cabecera.length; i++) {
				for (ACTIONS a : ACCIONES) {
					if (verbose)
						System.out.println("NOMBRE ACCION: " + a.toString());
					if (a.toString().equals(cabecera[i])) {
						actions[i] = a;
						if (verbose)
							System.out.println(actions[i] + " = " + a.toString());
						break;
					}
				}
			}

			while (fichero.hasNextLine()) {
				linea = fichero.nextLine();

				String[] campos = linea.split(";");

				// Seg�n el estado
				ESTADOS estado = ESTADOS.buscaEstado(campos[0]);

				// Por cada celda, le metemos el valor Q reemplazando coma por punto
				for (int i = 1; i < campos.length; i++)
					Q.put(new ParEstadoAccion(estado, actions[i]),
							Double.parseDouble(campos[i].replace(',', '.').replace('"', Character.MIN_VALUE)));

			}

			fichero.close();

		} catch (Exception ex) {
			System.out.println(ex.getMessage());
		}
	}

	public static ACTIONS getAccionMaxQ(ESTADOS s) {
		ACTIONS[] actions = StateManager.ACCIONES; // Acciones posibles
		ACTIONS accionMaxQ = ACTIONS.ACTION_NIL;

		double maxValue = Double.NEGATIVE_INFINITY; // - inf

		for (int i = 0; i < actions.length; i++) {

			// if(verbose) System.out.print("Actual maxQ<"+ s.toString() + "," );
			// if(verbose) System.out.print(actions[i]+"> = ");
			double value = StateManager.Q.get(new ParEstadoAccion(s, actions[i]));
			// if(verbose) System.out.println(value);

			if (value > maxValue) {
				maxValue = value;
				accionMaxQ = actions[i];
			}
		}

		if (maxValue == 0) // Inicialmente estan a 0, una random
		{

			int index = new Random().nextInt(StateManager.ACCIONES.length - 1);
			accionMaxQ = actions[index];

		}

		return accionMaxQ;
	}

// _____________________________________________________________________
//  METODOS PERCEPCION ESTADOS
//_____________________________________________________________________

	public static char[][] getMapa(StateObservation so) {
		char[][] res = new char[so.getWorldDimension().width / so.getBlockSize()][so.getWorldDimension().height
				/ so.getBlockSize()];

		for (int j = 0; j < so.getObservationGrid()[0].length; j++) {

			for (int i = 0; i < so.getObservationGrid().length; i++) {
				if (so.getObservationGrid()[i][j].size() != 0) {
					if (so.getObservationGrid()[i][j].get(0).category == 4) {
						res[i][j] = '#';
					} else if (so.getObservationGrid()[i][j].get(0).category == 0)
						res[i][j] = 'J';
					else if (so.getObservationGrid()[i][j].get(0).category == 2) {
						res[i][j] = 'M';
					} else {
						res[i][j] = 'C';
					}
				} else {
					res[i][j] = '-';
				}

			}
			System.out.println();
		}
		return res;
	}

	public static ESTADOS getEstadoFuturo(StateObservation obs, ACTIONS action) {

		obs.advance(action);
		return getEstado(obs, getMapa(obs));
	}

	public static ESTADOS getEstado(StateObservation obs, char[][] mapaObstaculos) {

		double[] pos = getCeldaPreciso(obs.getAvatarPosition(), obs.getWorldDimension());
		posActual = getIndiceMapa(pos);

		if (verbose)
			System.out.println("POS ACTUAL = " + pos[0] + "-" + pos[1]);
		if (verbose)
			System.out.println("POSICION REAL: " + obs.getAvatarPosition().toString());

		ArrayList<Observation>[] portalPosition = obs.getPortalsPositions();

		if (portalPosition[0].get(0).position.x > 20) {
			// portal se encuentra en la derecha
			metaDerecha = true;
		}else {
			metaDerecha = false;
		}
		
//		System.out.println(portalPosition[0].get(0).position.x  + " " + portalPosition[0].get(0).position.y);

		char[][] mapa = getMapa(obs);
		


		for (int i = 0; i < mapa.length; i++) {
			for (int j = 0; j < mapa[i].length; j++) {

				if (mapa[i][j] == 'J') {
					System.out.println("Entra Camello");
					//
					// hueco derecha
					if (metaDerecha && mapa[i][j + 1] == '-') {
						System.out.println("Hueco derecha");
						return ESTADOS.HUECO_DCHA;
					}

					if (!metaDerecha && mapa[i][j - 1] == '-') {
						System.out.println("Hueco izq");
						return ESTADOS.HUECO_IZQDA;
					}

					// Se hace para que no quede atrapado a causa de desplamiento contrario a la
					// meta
					if (mapa[i][j - 1] == '-') {
						return ESTADOS.HUECO_IZQDA;
					}
					if (mapa[i][j + 1] == '-') {
						return ESTADOS.HUECO_DCHA;
					}

					if (mapa[i + 1][j] == '-') {
						return ESTADOS.HUECO_ABAJO;

					}
					if (mapa[i - 1][j] == '-') {
						return ESTADOS.HUECO_ARRIBA;
					}

				}
				
			}
		}
		

		return ESTADOS.NIL;
	}

	public void getContadoresEstados() {
		System.out.println("____________ CONTADORES ESTADOS _____________________");
		for (ESTADOS s : ESTADOS.values()) {

			System.out.println(s.toString() + " : " + s.getContador());
		}
	}

// _____________________________________________________________________
//                    METODOS PERCEPCION MAPA
// _____________________________________________________________________

//	public static char[][] getMapaObstaculos(StateObservation obs)
//	{
//		// El desplazamiento de un jugador es en 0.5 casillas
//		char[][] mapaObstaculos = new char[numFilas*2][numCol*2];
//		
//		for(int i=0; i<numFilas*2; i++)
//			for(int j=0; j<numCol*2; j++)
//				mapaObstaculos[i][j] = ' ';
//		
//		
//	    	for(ArrayList<Observation> lista : obs.getMovablePositions())
//	    		for(Observation objeto : lista)
//	    		{
//	    			
//	    			double[] pos = getCeldaPreciso(objeto.position, obs.getWorldDimension()); // Posicion en casilla real 0.5
//	    			int [] indicePos = getIndiceMapa(pos); // Indice del mapa
//	    		
//	    			
//	    			//System.out.println("Objeto en " + pos[0] + "-" + pos[1] + " = "+ objeto.itype + " REAL: " + objeto.position.toString());
//	    			//System.out.println(this.mapaObstaculos[pos[0]][pos[1]]);
//	    			
//	    			switch(objeto.itype)
//					{    					
//						case 1:
//							mapaObstaculos[indicePos[0]][indicePos[1]] = 'O';
//							break;
//						case 10:
//						case 16:
//							mapaObstaculos[indicePos[0]][indicePos[1]] = '|';
//							break;
//						case 6:
//						case 7:
//						case 13:
//						case 14:
//							mapaObstaculos[indicePos[0]][indicePos[1]] = 'X';
//							break;
//						case 9:
//						case 15:
//							mapaObstaculos[indicePos[0]][indicePos[1]] = 'G';
//							break; 
//						default:
//							mapaObstaculos[indicePos[0]][indicePos[1]] = '.';
//							break;
//	    		}
//			}
//    	
//    	return mapaObstaculos;
//	}

	/*
	 * Obtiene la posicion en filas,col con precisi�n .5
	 */
	public static double[] getCeldaPreciso(Vector2d vector, Dimension dim) {

		double x = vector.x / dim.getWidth() * numCol;
		double y = vector.y / dim.getHeight() * numFilas;

		return new double[] { y, x };
	}

	/*
	 * Devuelve el indice del mapa de obstaculos que corresponde el parametro de
	 * posicion
	 */
	public static int[] getIndiceMapa(double[] pos) {
		return new int[] { (int) (pos[0] * 2), (int) (pos[1] * 2) };
	}

// _____________________________________________________________________
//  METODOS VISUALES
//_____________________________________________________________________	
	public static void pintaQTable(ESTADOS s) {
		ACTIONS[] actions = StateManager.ACCIONES;

		System.out.println("----------Q TABLE -----------------");

		for (int i = 0; i < actions.length; i++) {
			System.out.print("Actual Q<" + s.toString() + ",");
			System.out.print(actions[i] + "> = ");

			double value = StateManager.Q.get(new ParEstadoAccion(s, actions[i]));

			System.out.println(value);
		}

		System.out.println("----------Q TABLE -----------------");
	}

	public static void pintaQTableResumen() {

		ESTADOS[] estados = ESTADOS.values();

		System.out.println("____________________ Q TABLE RESUMEN ______________________");

		for (int i = 0; i < estados.length; i++) {
			ACTIONS accion = getAccionMaxQ(estados[i]);
			double q = StateManager.Q.get(new ParEstadoAccion(estados[i], accion));

			System.out.println("maxQ<" + estados[i].toString() + "," + accion.toString() + "> = " + q);

		}

		System.out.println("_________________________________________________________");
	}

	public static void showMapa(StateObservation so) {

		for (int j = 0; j < so.getObservationGrid()[0].length; j++) {

			for (int i = 0; i < so.getObservationGrid().length; i++) {
				if (so.getObservationGrid()[i][j].size() != 0) {

					if (so.getObservationGrid()[i][j].get(0).itype == 0) {
						System.out.print("#");
					} else if (so.getObservationGrid()[i][j].get(0).category == 0) {
						System.out.print("J");
					} else if (so.getObservationGrid()[i][j].get(0).category == 2) {
						System.out.print("M");
					} else {
						System.out.print("-");
					}
				}

			}
			System.out.println();
		}
	}

}